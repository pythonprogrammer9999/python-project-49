### Hexlet tests and linter status:
[![Actions Status](https://github.com/pythonprogrammer9999/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/pythonprogrammer9999/python-project-49/actions)
brain-calc https://asciinema.org/a/48bkCuhCwDoS0ZihAFslhjs1V
brain-even https://asciinema.org/a/f6yA2KdqvXwHY4Z5IBqLVlScY
brain-gcd https://asciinema.org/a/Ql7c4Z4CzdtSwTJZ0SAE3c4A9
brain-progression https://asciinema.org/a/XXwIf0dcu33JeUI8XNoE0eUus
brain-prime https://asciinema.org/a/fbLbvVFhrbkcAXpJzB2EJrBCl
