### Hexlet tests and linter status:
[![Actions Status](https://github.com/pythonprogrammer9999/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/pythonprogrammer9999/python-project-49/actions)
https://asciinema.org/a/f6yA2KdqvXwHY4Z5IBqLVlScY
https://asciinema.org/a/Ql7c4Z4CzdtSwTJZ0SAE3c4A9
    